
// const table = document.getElementById("internship-table");
// const tbody = document.getElementById("table-body");
// const status = document.getElementById("status");

// const PROSPLE_URL = "https://in.prosple.com/search-jobs?locations=9826&opportunity_types=2&from_seo=1&content=internships-india&industry_sectors=754%2C24087%2C756%2C762";

// export async function scrapeProspleInternships() {
//   status.textContent = "Opening Prosple page and scraping...";

//   try {
//     const tab = await chrome.tabs.create({ url: PROSPLE_URL, active: false });

//     setTimeout(() => {
//       chrome.scripting.executeScript(
//         {
//           target: { tabId: tab.id },
//           func: scrapeProspleJobs
//         },
//         (results) => {
//           if (results && results[0] && results[0].result) {
//             const internships = results[0].result;

//             tbody.innerHTML = "";
//             internships.forEach(job => {
//               const tr = document.createElement("tr");
//               tr.innerHTML = `
//                 <td>${job.Title}</td>
//                 <td>${job.Company}</td>
//                 <td>${job.Location}</td>
//                 <td>${job.Stipend}</td>
//                 <td>${job.Start_Date}</td>
//                 <td>${job.Apply_By}</td>
//                 <td>${job.Category}</td>
//                 <td><img src="${job.Company_Logo_URL}" width="50"/></td>
//                 <td><a href="${job.Detail_URL}" target="_blank">Apply</a></td>
//               `;
//               tbody.appendChild(tr);
//             });

//             status.style.display = "none";
//             table.style.display = "table";

//             chrome.tabs.remove(tab.id);
//           }
//         }
//       );
//     }, 8000); // Wait 8 sec for dynamic content
//   } catch (err) {
//     status.textContent = "Error: " + err.message;
//   }
// }

// // Function to run inside Prosple page
// function scrapeProspleJobs() {
//   const cards = document.querySelectorAll('li.SearchResultsstyle__SearchResult-sc-c560t5-1');
//   const internships = [];

//   cards.forEach(card => {
//     const getText = (selector) => card.querySelector(selector)?.innerText.trim() || '';
//     const getHref = (selector) => card.querySelector(selector)?.href || '';
//     const getImg = (selector) => card.querySelector(selector)?.src || '';

//     const getByXPath = (xpath) => {
//       try {
//         const el = document.evaluate(xpath, card, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
//         return el?.innerText.trim() || '';
//       } catch(e) { return ''; }
//     };

//     internships.push({
//       Title: getText('h2 a'),
//       Detail_URL: getHref('h2 a'),
//       Company: getText('p.JobTeaserstyle__JobTeaserEmployerTitle-sc-18thvj0-5'),
//       Location: getText('p.JobTeaserstyle__JobTeaserLocation-sc-18thvj0-15'),
//       Stipend: getText('span.JobTeaserstyle__JobTeaserSalaryValue-sc-18thvj0-21'),
//       Start_Date: getByXPath(".//div[contains(text(),'Start Date')]/following-sibling::div"),
//       Apply_By: getByXPath(".//div[@data-testid='badge']/p/span"),
//       Category: getByXPath(".//div[contains(@class, 'JobTeaserstyle__JobTeaserStudyFieldsContentWrapper')]/span"),
//       Company_Logo_URL: getImg('div.JobTeaserstyle__JobTeaserEmployerLogoMobileWrapper-sc-18thvj0-11 img')
//     });
//   });

//   return internships;
// }


const PROSPLE_URL = "https://in.prosple.com/search-jobs?locations=9826&opportunity_types=2&from_seo=1&content=internships-india";

export async function scrapeProspleInternships() {
  try {
    const tab = await chrome.tabs.create({ url: PROSPLE_URL, active: false });

    return await new Promise((resolve) => {
      setTimeout(() => {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            func: scrapeProspleJobs
          },
          (results) => {
            chrome.tabs.remove(tab.id);
            if (!results || !results[0]) return resolve([]);
            resolve(results[0].result || []);
          }
        );
      }, 8000);
    });
  } catch (err) {
    console.error("Prosple Error:", err);
    return [];
  }
}

// Runs inside Prosple page
function scrapeProspleJobs() {
  // 🔥 NEW VALID SELECTOR (working in 2025)
  const cards = document.querySelectorAll("li.sc-3bbad5b8-1");
  const internships = [];

  cards.forEach(card => {
    const getText = (sel) => card.querySelector(sel)?.innerText.trim() || '';
    const getHref = (sel) => card.querySelector(sel)?.href || '';
    const getImg = (sel) => card.querySelector(sel)?.src || '';

    const getByXPath = (xpath) => {
      try {
        const el = document.evaluate(xpath, card, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        return el?.innerText.trim() || '';
      } catch (e) { return ''; }
    };

    const Title = getText("h2 a");
    const Company = getText("p.sc-692f12d5-5");

    // real apply link
    let Apply_Link = getHref("a[data-event-track='cta-apply']");

    // 🌟 GOOGLE FALLBACK
    if (!Apply_Link || Apply_Link.trim() === "") {
      Apply_Link =
        "https://www.google.com/search?q=" +
        encodeURIComponent(`${Title} ${Company} internship apply`);
    }

    internships.push({
      Title,
      Detail_URL: getHref("h2 a"),
      Company,
      Location: getText("p.sc-692f12d5-15"),
      Stipend: "",  // prosple rarely shows stipend
      Start_Date: getByXPath(".//div[text()='Start Date']/following-sibling::div"),
      Apply_By: "",
      Category: getText("div.sc-692f12d5-30 span"),
      Apply_Link,
      Company_Logo_URL: getImg("img")
    });
  });

  return internships;
}
