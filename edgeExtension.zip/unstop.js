const UNSTOP_URL = "https://unstop.com/internships";

export async function scrapeUnstop(refresh = true) {
  try {
    const tab = await chrome.tabs.create({ url: UNSTOP_URL, active: false });

    return await new Promise((resolve) => {
      // Wait for page to load completely
      setTimeout(() => {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            func: scrapeUnstopJobs
          },
          async (results) => {
            chrome.tabs.remove(tab.id);

            if (!results || !results[0]) return resolve([]);
            const data = results[0].result || [];
            resolve(data);
          }
        );
      }, 8000); // Adjust delay if necessary
    });
  } catch (err) {
    console.error("Unstop Scrape Error:", err);
    alert("error vayo")
    return [];
  }
}

// Runs inside Unstop page
function scrapeUnstopJobs() {
  const internships = [];
  const internshipCards = document.querySelectorAll('a.item');

  internshipCards.forEach(card => {
    try {
      const data = {};

      // Role
      data['Role'] = card.querySelector('h2.double-wrap')?.innerText?.trim() || '';

      // Company Name
      data['Company Name'] = card.querySelector('p.single-wrap')?.innerText?.trim() || '';

      // Locations
      const locations = card.querySelectorAll('div.other_fields span');
      data['Primary Location'] = locations[1]?.innerText?.trim() || '';
      data['Secondary Location'] = locations[3]?.innerText?.trim() || '';

      // Work Type
      const workType = Array.from(card.querySelectorAll('span'))
        .find(el => el.innerText.includes('Part') || el.innerText.includes('Full'));
      data['Work Type'] = workType?.innerText?.trim() || '';

      // Skills
      const skills = card.querySelectorAll('.left-tags span.font-12');
      data['Skills'] = Array.from(skills).map(s => s.innerText.trim());

      // Stipend
      const stipend = card.querySelectorAll('div.cash_widget strong');
      data['Stipend'] = Array.from(stipend).map(s => s.innerText.trim()).join(' - ');

      // Posting Date & Days Left
      const posting = Array.from(card.querySelectorAll('span'))
        .find(s => s.innerText.includes('Posted'));
      data['Posting Date'] = posting?.innerText.replace("Posted ", "").trim() || '';
      const daysLeft = posting?.nextElementSibling;
      data['Days Left'] = daysLeft?.innerText?.trim() || '';

      // Apply Link
      data['Apply Link'] = card.href;

      internships.push(data);
    } catch (e) {
      console.error("Unstop card parse error:", e);
    }
  });

  return internships;
}
