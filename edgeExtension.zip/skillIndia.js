const SOURCE_URL = "https://www.skillindiadigital.gov.in/internship";

export async function scrapeSkillIndiaInternships() {
    try {
        const tab = await chrome.tabs.create({ url: SOURCE_URL, active: false });

        return await new Promise((resolve) => {
            setTimeout(() => {
                chrome.scripting.executeScript(
                    {
                        target: { tabId: tab.id },
                        func: scrapeSkillIndia
                    },
                    (results) => {
                        chrome.tabs.remove(tab.id);
                        if (!results || !results[0]) return resolve([]);
                        resolve(results[0].result || []);
                    }
                );
            }, 7000); // Give time for checkbox-triggered filtering
        });
    } catch (err) {
        console.error("Skill India Scraper Error:", err);
        return [];
    }
}

// Runs inside the internship page
function scrapeSkillIndia() {

    // ✅ Step 1: Click the IT-ITeS checkbox
    const checkbox = document.querySelector('input[name="IT-ITeS"]');

    if (checkbox && !checkbox.checked) {
        checkbox.click();

        // Trigger Angular/Material events just in case
        checkbox.dispatchEvent(new Event("change", { bubbles: true }));
        checkbox.dispatchEvent(new Event("input", { bubbles: true }));
    }

    // Wait for filter to update UI (Material takes a moment)
    const delay = (ms) => new Promise(res => setTimeout(res, ms));

    return (async () => {
        await delay(1000);

        // ===========================
        //  Scraping begins
        // ===========================
        const cards = document.querySelectorAll("app-internship-card .event-card");
        if (!cards.length) return [];

        const internships = [];

        cards.forEach(card => {
            const title = card.querySelector("h3")?.innerText.trim() || "";
            const company = card.querySelector(".time-technology span")?.innerText.trim() || "";
            const fees = card.querySelector(".course-fees")?.innerText.trim() || "";
            const department = card.querySelector(".internship-dep")?.innerText.trim() || "";
            const description = card.querySelector(".description-list-value")?.innerText.trim() || "";
            const duration = card.querySelector(".duration-list-value")?.innerText.replace("Duration:", "").trim() || "";

            const openingsElem = card.querySelector(".tag-blue");
            const openings = openingsElem?.innerText.trim() || "0 Openings";

            const image = card.querySelector("img")?.src || "";

            // No real apply button — use Google fallback
            let Apply_Link =
                "https://www.google.com/search?q=" +
                encodeURIComponent(`${title} ${company} internship apply`);

            internships.push({
                title,
                company,
                fees,
                department,
                description,
                duration,
                openings,
                image,
                Apply_Link
            });
        });

        return internships;
    })();
}
