// const table = document.getElementById("internship-table");
// const tbody = document.getElementById("table-body");
// const status = document.getElementById("status");

// const URL = "https://internshala.com/internships/net-development,android-app-development,computer-science,web-development-internship/";

// export async function scrapeInternshala() {
//   status.textContent = "Opening Internshala and scraping...";
//   try {
//     // Open Internshala in a new tab (inactive)
//     const tab = await chrome.tabs.create({ url: URL, active: false });

//     // Wait a few seconds for the page to load
//     setTimeout(async () => {
//       chrome.scripting.executeScript(
//         {
//           target: { tabId: tab.id },
//           func: scrapeInterns
//         },
//         (results) => {
//           if (results && results[0] && results[0].result) {
//             const internships = results[0].result;
//             tbody.innerHTML = "";
//             internships.forEach(job => {
//               const tr = document.createElement("tr");
//               tr.innerHTML = `
//                 <td>${job.role}</td>
//                 <td>${job.company}</td>
//                 <td>${job.location}</td>
//                 <td>${job.stipend}</td>
//                 <td>${job.duration}</td>
//                 <td><a href="${job.applyLink}" target="_blank">Apply</a></td>
//               `;
//               tbody.appendChild(tr);
//             });
//             status.style.display = "none";
//             table.style.display = "table";

//             // Close the temporary tab
//             chrome.tabs.remove(tab.id);
//           }
//         }
//       );
//     }, 5000); // adjust time if Internshala takes longer to load
//   } catch (err) {
//     status.textContent = "Error: " + err.message;
//   }
// }

// // This function runs in the context of Internshala page
// function scrapeInterns() {
//   const container = document.getElementById("internship_list_container");
//   if (!container) return [];

//   const internships = [];
//   const list = container.querySelectorAll('div[id^="individual_internship_"]');
//   list.forEach(item => {
//     const roleElem = item.querySelector("a.job-title-href");
//     const companyElem = item.querySelector("p.company-name");
//     const locationElem = item.querySelector("div.locations span");
//     const stipendElem = item.querySelector('div.row-1-item i.ic-16-money')?.parentElement.querySelector("span");
//     const durationElem = item.querySelector('div.row-1-item i.ic-16-calendar')?.parentElement.querySelector("span");

//     internships.push({
//       role: roleElem ? roleElem.innerText.trim() : "",
//       company: companyElem ? companyElem.innerText.trim() : "",
//       location: locationElem ? locationElem.innerText.trim() : "",
//       stipend: stipendElem ? stipendElem.innerText.trim() : "",
//       duration: durationElem ? durationElem.innerText.trim() : "",
//       applyLink: roleElem ? roleElem.href : ""
//     });
//   });
//   return internships;
// }

const IS_URL = "https://internshala.com/internships/computer-science-internship/";

export async function scrapeInternshala() {
    try {
        const tab = await chrome.tabs.create({ url: IS_URL, active: false });

        return await new Promise((resolve) => {
            setTimeout(() => {
                chrome.scripting.executeScript(
                    {
                        target: { tabId: tab.id },
                        func: scrapeInterns
                    },
                    (results) => {
                        chrome.tabs.remove(tab.id);
                        if (!results || !results[0]) return resolve([]);
                        resolve(results[0].result || []);
                    }
                );
            }, 10000);
        });
    } catch (err) {
        console.error("Internshala Error:", err);
        return [];
    }
}

// Runs inside Internshala page
function scrapeInterns() {
    const container = document.getElementById("internship_list_container");
    if (!container) return [];

    const internships = [];

    const list = container.querySelectorAll('div[id^="individual_internship_"]');
    list.forEach(item => {
        const roleElem = item.querySelector("a.job-title-href");
        const companyElem = item.querySelector("p.company-name");
        const locationElem = item.querySelector("div.locations span");
        const stipendElem = item.querySelector('i.ic-16-money')?.parentElement.querySelector("span");
        const durationElem = item.querySelector('i.ic-16-calendar')?.parentElement.querySelector("span");

        let role = roleElem?.innerText.trim() || "";
        let company = companyElem?.innerText.trim() || "";

        let Apply_Link = roleElem?.href || "";

        // 🌟 GOOGLE FALLBACK
        if (!Apply_Link || Apply_Link.trim() === "") {
            Apply_Link =
                "https://www.google.com/search?q=" +
                encodeURIComponent(`${role} ${company} internship apply`);
        }

        internships.push({
            role,
            company,
            location: locationElem?.innerText.trim() || "",
            stipend: stipendElem?.innerText.trim() || "",
            duration: durationElem?.innerText.trim() || "",
            Apply_Link
        });

    });

    return internships;
}

