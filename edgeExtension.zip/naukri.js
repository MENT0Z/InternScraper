// const table = document.getElementById("internship-table");
// const tbody = document.getElementById("table-body");
// const status = document.getElementById("status");

// const NAUKRI_URL = "https://www.naukri.com/internship-jobs?functionAreaIdGid=3&functionAreaIdGid=4&functionAreaIdGid=5&functionAreaIdGid=8&functionAreaIdGid=15&functionAreaIdGid=30";

// export async function scrapeNaukriInternships() {
//   status.textContent = "Opening Naukri page and scraping...";
//   try {
//     const tab = await chrome.tabs.create({ url: NAUKRI_URL, active: false });

//     setTimeout(() => {
//       chrome.scripting.executeScript(
//         {
//           target: { tabId: tab.id },
//           func: scrapeNaukriJobs
//         },
//         (results) => {
//           if (results && results[0] && results[0].result) {
//             const jobs = results[0].result;

//             tbody.innerHTML = "";
//             jobs.forEach(job => {
//               const tr = document.createElement("tr");
//               tr.innerHTML = `
//                 <td>${job.name}</td>
//                 <td>${job.company}</td>
//                 <td>${job.location}</td>
//                 <td>${job.stipend}</td>
//                 <td>${job.duration}</td>
//                 <td>${job.starts_within}</td>
//                 <td>${job.rating}</td>
//                 <td>${job.total_review}</td>
//                 <td><a href="${job.apply_link}" target="_blank">Apply</a></td>
//               `;
//               tbody.appendChild(tr);
//             });

//             status.style.display = "none";
//             table.style.display = "table";

//             // Close temporary tab
//             chrome.tabs.remove(tab.id);
//           }
//         }
//       );
//     }, 8000); // Wait 8 seconds for page to load
//   } catch (err) {
//     status.textContent = "Error: " + err.message;
//   }
// }

// // Function to run inside Naukri page
// function scrapeNaukriJobs() {
//   const jobElements = document.querySelectorAll('.srp-jobtuple-wrapper');
//   const jobs = [];

//   jobElements.forEach(job => {
//     const getText = (selector) => job.querySelector(selector)?.innerText.trim() || '';
//     const getHref = (selector) => job.querySelector(selector)?.href || '';

//     jobs.push({
//       name: getText('h2 a.title'),
//       company: getText('.comp-name'),
//       location: getText('.loc-wrap span.locWdth'),
//       stipend: getText('.sal-wrap span'),
//       duration: getText('.exp-wrap span'),
//       starts_within: getText('.job-post-day'),
//       rating: getText('a.rating span.main-2'),
//       total_review: getText('a.review'),
//       apply_link: getHref('h2 a.title')
//     });
//   });

//   return jobs;
// }


const NAUKRI_URL = "https://www.naukri.com/internship-jobs";

export async function scrapeNaukriInternships() {
    try {
        const tab = await chrome.tabs.create({ url: NAUKRI_URL, active: false });

        return await new Promise((resolve) => {
            setTimeout(() => {
                chrome.scripting.executeScript(
                    {
                        target: { tabId: tab.id },
                        func: scrapeNaukriJobs
                    },
                    (results) => {
                        chrome.tabs.remove(tab.id);
                        if (!results || !results[0]) return resolve([]);
                        resolve(results[0].result || []);
                    }
                );
            }, 10000);
        });
    } catch (err) {
        console.error("Naukri Error:", err);
        return [];
    }
}

// Runs inside Naukri page
function scrapeNaukriJobs() {
    const jobs = [];
    const elems = document.querySelectorAll('.srp-jobtuple-wrapper');

    elems.forEach(job => {
        const getText = (sel) => job.querySelector(sel)?.innerText.trim() || '';
        const getHref = (sel) => job.querySelector(sel)?.href || '';

        jobs.push({
            name: getText('h2 a.title'),
            company: getText('.comp-name'),
            location: getText('.loc-wrap span.locWdth'),
            stipend: getText('.sal-wrap span'),
            duration: getText('.exp-wrap span'),
            starts_within: getText('.job-post-day'),
            rating: getText('a.rating span.main-2'),
            total_review: getText('a.review'),

            // Apply link + fallback
            apply_link: (() => {
                let title = getText('h2 a.title');
                let company = getText('.comp-name');
                let href = getHref('h2 a.title');

                if (!href || href.trim() === "") {
                    return "https://www.google.com/search?q=" +
                        encodeURIComponent(`${title} ${company} internship apply`);
                }
                return href;
            })()
        });

    });

    return jobs;
}
