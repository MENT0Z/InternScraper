const LINKEDIN_URL = "https://in.linkedin.com/jobs/current-openings-in-india-jobs?position=1&pageNum=0";

export async function scrapeLinkedInJobs() {
    try {
        const tab = await chrome.tabs.create({ url: LINKEDIN_URL, active: false });

        return await new Promise((resolve) => {
            setTimeout(() => {
                chrome.scripting.executeScript(
                    {
                        target: { tabId: tab.id },
                        func: scrapeLinkedIn
                    },
                    (results) => {
                        chrome.tabs.remove(tab.id);
                        if (!results || !results[0]) return resolve([]);
                        resolve(results[0].result || []);
                    }
                );
            }, 8000); // LinkedIn requires more loading time
        });
    } catch (err) {
        console.error("LinkedIn Scraper Error:", err);
        return [];
    }
}


// Runs inside LinkedIn page
function scrapeLinkedIn() {

    const delay = (ms) => new Promise(res => setTimeout(res, ms));

    return (async () => {

        // ----------------------------------------
        // ✅ STEP 1: Close any popup if it appears
        // ----------------------------------------
        function closeLinkedInPopup() {
            const closeBtn =
                document.querySelector(".modal__dismiss") ||
                document.querySelector(".contextual-sign-in-modal__modal-dismiss") ||
                document.querySelector("button[aria-label='Dismiss']");

            if (closeBtn) {
                closeBtn.click();
                console.log("Popup closed");
                return true;
            }
            return false;
        }

        // Try to close popup repeatedly (LinkedIn loads it late)
        for (let i = 0; i < 5; i++) {
            if (closeLinkedInPopup()) break;
            await delay(500);
        }

        // Wait extra time for UI to settle
        await delay(1000);

        // ----------------------------------------
        // ✅ STEP 2: SCRAPE JOB LIST
        // ----------------------------------------
        const list = document.querySelectorAll(
            '#main-content section.two-pane-serp-page__results-list ul > li'
        );

        if (!list.length) return [];

        const jobs = [];

        list.forEach(li => {

            const jobCard = li.querySelector(".base-search-card");
            if (!jobCard) return;

            const Title = jobCard.querySelector(".base-search-card__title")?.innerText.trim() || "";
            const company = jobCard.querySelector(".base-search-card__subtitle a")?.innerText.trim() || "";
            const location = jobCard.querySelector(".job-search-card__location")?.innerText.trim() || "";
            const posted = jobCard.querySelector("time")?.innerText.trim() || "";
            const logo = jobCard.querySelector("img")?.src || "";

            const Apply_Link = jobCard.querySelector("a.base-card__full-link")?.href || "";

            const activelyHiring = !!jobCard.querySelector(".job-posting-benefits__text");

            jobs.push({
                Title,
                company,
                location,
                posted,
                activelyHiring,
                logo,
                Apply_Link
            });
        });

        return jobs;

    })();
}
