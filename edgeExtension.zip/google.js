// const table = document.getElementById("internship-table");
// const tbody = document.getElementById("table-body");
// const status = document.getElementById("status");

// const GOOGLE_URL = "https://www.google.com/search?sca_esv=0df777c87af9a454&udm=8&biw=1705&bih=842&sxsrf=AHTn8zqRD5UM_dRztMAoLFNiUv_bseN0fw%3A1741789311708&q=current%20internships%20in%20india%20Internship";

// export async function scrapeGoogleInternships() {
//   status.textContent = "Opening Google internships page and scraping...";

//   try {
//     const tab = await chrome.tabs.create({ url: GOOGLE_URL, active: false });

//     setTimeout(() => {
//       chrome.scripting.executeScript(
//         {
//           target: { tabId: tab.id },
//           func: scrapeGoogleJobs
//         },
//         (results) => {
//           if (results && results[0] && results[0].result) {
//             const internships = results[0].result;

//             tbody.innerHTML = "";
//             internships.forEach(job => {
//               const tr = document.createElement("tr");
//               tr.innerHTML = `
//                 <td>${job.Role}</td>
//                 <td>${job["Company Name"] || ''}</td>
//                 <td>${job["Location And Source"] || ''}</td>
//                 <td>${job.Stipend || ''}</td>
//                 <td>${job.Role_Type || ''}</td>
//                 <td>${job.Posted_Date || ''}</td>
//               `;
//               tbody.appendChild(tr);
//             });

//             status.style.display = "none";
//             table.style.display = "table";

//             // Close temporary tab
//             chrome.tabs.remove(tab.id);
//           }
//         }
//       );
//     }, 8000); // Wait 8 sec for page to load; increase if needed
//   } catch (err) {
//     status.textContent = "Error: " + err.message;
//   }
// }

// // Function to run inside Google internships page
// function scrapeGoogleJobs() {
//   const internshipCards = document.querySelectorAll('div[jscontroller="b11o3b"]');
//   const internships = [];

//   internshipCards.forEach(card => {
//     const data = {};
//     try {
//       data['Role'] = card.querySelector('div.tNxQIb.PUpOsf')?.innerText || '';
//       data['Company Name'] = card.querySelector('div.wHYlTd.MKCbgd.a3jPc')?.innerText || '';
//       data['Location And Source'] = card.querySelector('div.wHYlTd.FqK3wc.MKCbgd')?.innerText || '';

//       const details = card.querySelectorAll('div.K3eUK');
//       details.forEach(detail => {
//         const label = detail.querySelector('span.Yf9oye')?.getAttribute('aria-label') || '';
//         const value = detail.querySelector('span.Yf9oye span[aria-hidden="true"]')?.innerText || '';
//         if (label.includes("Posted")) data['Posted_Date'] = value;
//         if (label.includes("Employment type")) data['Role_Type'] = value;
//       });

//       data['Stipend'] = card.querySelector('div.K3eUK.QZEeP span.Yf9oye span[aria-hidden="true"]')?.innerText || '';
//     } catch(e) {}
//     internships.push(data);
//   });

//   return internships;
// }


// const GOOGLE_URL = "https://www.google.com/search?sca_esv=0df777c87af9a454&udm=8&biw=1705&bih=842&sxsrf=AHTn8zqRD5UM_dRztMAoLFNiUv_bseN0fw%3A1741789311708&q=current%20internships%20in%20india%20Internship";

// export async function scrapeGoogleInternships() {
//   try {
//     const tab = await chrome.tabs.create({ url: GOOGLE_URL, active: false });

//     return await new Promise((resolve) => {
//       setTimeout(() => {
//         chrome.scripting.executeScript(
//           {
//             target: { tabId: tab.id },
//             func: scrapeGoogleJobs
//           },
//           (results) => {
//             chrome.tabs.remove(tab.id);

//             if (!results || !results[0]) return resolve([]);
//             resolve(results[0].result || []);
//           }
//         );
//       }, 8000);
//     });
//   } catch (err) {
//     console.error("Google Scrape Error:", err);
//     return [];
//   }
// }

// // Runs inside Google page
// function scrapeGoogleJobs() {
//   const internshipCards = document.querySelectorAll('div[jscontroller="b11o3b"]');
//   const internships = [];

//   internshipCards.forEach(card => {
//     const data = {};
//     try {
//       data['Role'] = card.querySelector('div.tNxQIb.PUpOsf')?.innerText || '';
//       data['Company Name'] = card.querySelector('div.wHYlTd.MKCbgd.a3jPc')?.innerText || '';
//       data['Location And Source'] = card.querySelector('div.wHYlTd.FqK3wc.MKCbgd')?.innerText || '';

//       const details = card.querySelectorAll('div.K3eUK');
//       details.forEach(detail => {
//         const label = detail.querySelector('span.Yf9oye')?.getAttribute('aria-label') || '';
//         const value = detail.querySelector('span.Yf9oye span[aria-hidden="true"]')?.innerText || '';
//         if (label.includes("Posted")) data['Posted_Date'] = value;
//         if (label.includes("Employment type")) data['Role_Type'] = value;
//       });
      

//       data['Stipend'] = card.querySelector('div.K3eUK.QZEeP span.Yf9oye span[aria-hidden="true"]')?.innerText || '';
//        // 🌟 GOOGLE FALLBACK
//         if (!Apply_Link || Apply_Link.trim() === "") {
//         Apply_Link =
//             "https://www.google.com/search?q=" +
//             encodeURIComponent(`${Title} ${Company} internship apply`);
//         }
//     } catch (e) {}

//     internships.push(data);
//   });

//   return internships;
// }
const GOOGLE_URL = "https://www.google.com/search?sca_esv=0df777c87af9a454&udm=8&biw=1705&bih=842&sxsrf=AHTn8zqRD5UM_dRztMAoLFNiUv_bseN0fw%3A1741789311708&q=current%20internships%20in%20india%20Internship";

export async function scrapeGoogleInternships() {
  try {
    const tab = await chrome.tabs.create({ url: GOOGLE_URL, active: false });

    return await new Promise((resolve) => {
      setTimeout(() => {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            func: scrapeGoogleJobs
          },
          (results) => {
            chrome.tabs.remove(tab.id);

            if (!results || !results[0]) return resolve([]);
            resolve(results[0].result || []);
          }
        );
      }, 8000);
    });
  } catch (err) {
    console.error("Google Scrape Error:", err);
    return [];
  }
}

// Runs inside Google page
function scrapeGoogleJobs() {
  const internshipCards = document.querySelectorAll('div[jscontroller="b11o3b"]');
  const internships = [];

  internshipCards.forEach(card => {
    const data = {};

    try {
      // Role (Job Title)
      const Role = card.querySelector('div.tNxQIb.PUpOsf')?.innerText?.trim() || '';

      // Company
      const Company = card.querySelector('div.wHYlTd.MKCbgd.a3jPc')?.innerText?.trim() || '';

      // Location + Source (e.g., LinkedIn · Delhi)
      const Location_And_Source =
        card.querySelector('div.wHYlTd.FqK3wc.MKCbgd')?.innerText?.trim() || '';

      // Posted date + Role type + Other metadata
      const details = card.querySelectorAll('div.K3eUK');
      let Posted_Date = "";
      let Role_Type = "";
      let Stipend = "";

      details.forEach(detail => {
        const label = detail.querySelector('span.Yf9oye')?.getAttribute('aria-label') || '';
        const value = detail.querySelector('span.Yf9oye span[aria-hidden="true"]')?.innerText || '';

        if (label.includes("Posted")) Posted_Date = value;
        if (label.includes("Employment type")) Role_Type = value;
        if (label.includes("Salary") || label.includes("Stipend")) Stipend = value;
      });

      // Apply link – Google job card metadata
      let Apply_Link = card.querySelector('a.MjU33b')?.href || "";

      // 🌟 Fallback to Google search if empty
      if (!Apply_Link || Apply_Link.trim() === "") {
        Apply_Link =
          "https://www.google.com/search?q=" +
          encodeURIComponent(`${Role} ${Company} internship apply`);
      }

      data['Role'] = Role;
      data['Company Name'] = Company;
      data['Location And Source'] = Location_And_Source;
      data['Posted_Date'] = Posted_Date;
      data['Role_Type'] = Role_Type;
      data['Stipend'] = Stipend;
      data['Apply_Link'] = Apply_Link;

    } catch (e) {
      console.error("Google card parse err:", e);
    }

    internships.push(data);
  });

  return internships;
}
