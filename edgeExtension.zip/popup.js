import { scrapeInternshala } from './internshala.js';
import { scrapeGoogleInternships } from './google.js';
import { scrapeNaukriInternships } from './naukri.js';
import { scrapeHelloIntern } from './helloIntern.js';
import { scrapeProspleInternships } from './prosple.js';
import { scrapeUnstop } from './unstop.js';
import { scrapeSkillIndiaInternships } from './skillIndia.js';
import { scrapeLinkedInJobs } from './linkedin.js';

const table = document.getElementById("internship-table");
const tbody = document.getElementById("table-body");
const status = document.getElementById("status");
const refreshBtn = document.getElementById("refresh-btn");
const searchBar = document.getElementById("search-bar");
const paidOnlyCheckbox = document.getElementById("paid-only");

let cachedResults = {};
let bookmarks = {}; // { id: jobData }
const homeBtn = document.getElementById("home-btn");
const scrapers = [
    { fn: scrapeInternshala, name: "Internshala" },
    { fn: scrapeGoogleInternships, name: "Google" },
    { fn: scrapeNaukriInternships, name: "Naukri" },
    { fn: scrapeHelloIntern, name: "HelloIntern" },
    { fn: scrapeProspleInternships, name: "Prosple" },
    { fn: scrapeUnstop, name: "Unstop" },
    { fn: scrapeSkillIndiaInternships, name: "SkillIndia" },
    { fn: scrapeLinkedInJobs, name: "Linkedin" }
];

// ---------- Helpers ----------
function s(v) {
    if (typeof v === 'string') return v.trim();
    if (typeof v === 'number') return String(v);
    return '';
}

function showLoading() {
    document.getElementById("loading-overlay").style.display = "flex";
}

function hideLoading() {
    document.getElementById("loading-overlay").style.display = "none";
}


function pickFirst(obj, keys) {
    for (const k of keys) {
        if (!obj) continue;
        const v = obj[k];
        if (v !== undefined && v !== null) {
            const sv = s(v);
            if (sv.length) return sv;
        }
    }
    return '';
}

function pickAnyString(obj) {
    if (!obj || typeof obj !== 'object') return '';
    for (const k of Object.keys(obj)) {
        const v = obj[k];
        if (typeof v === 'string' && v.trim().length) return v.trim();
        if (typeof v === 'number') return String(v);
    }
    return '';
}
function normalizeJob(siteName, job) {
    if (siteName.toLowerCase() === "unstop") {
        const url = job["Apply Link"] || job.Detail_URL || '';
        let title = job.Role || "";
        let company = job["Company Name"] || "";

        // If Role or Company is missing, try parsing from URL
        if (url.includes("/internships/") && (!title || !company)) {
            const afterInternship = url.split("/internships/")[1].replace(/-\d+$/, "");
            const splitIndex = afterInternship.toLowerCase().lastIndexOf("-internship-");

            if (splitIndex !== -1) {
                if (!title) {
                    title = afterInternship.substring(0, splitIndex + "-internship".length).replace(/-/g, ' ');
                }
                if (!company) {
                    company = afterInternship.substring(splitIndex + "-internship-".length).replace(/-/g, ' ');
                }
            } else {
                if (!title) title = afterInternship.replace(/-/g, ' ');
            }
        }

        const location = job["Primary Location"] || job["Secondary Location"] || "";
        const stipend = job.Stipend || "not specified";
        const duration = job["Days Left"] || "";

        return {
            Website: siteName,
            Title: title,
            Company: company,
            Location: location,
            StipendOrDuration: stipend || duration,
            Apply_URL: url || "#"
        };
    }
    // default normalization for other sites
    const title = pickFirst(job, ['Title', 'title', 'Role', 'role', 'name', 'Name']) || pickAnyString(job);
    const company = pickFirst(job, ['Company', 'company', 'Company Name', 'employer', 'Employer', 'Company_Name']) || '';
    const location = pickFirst(job, ['Location', 'location', 'Location And Source', 'loc', 'city', 'Primary_Location', 'Secondary_Location']) || '';
    const stipend = pickFirst(job, ['Stipend', 'stipend', 'salary', 'Salary']) || '';
    const duration = pickFirst(job, ['Duration', 'duration', 'durationText', 'Days_Left']) || '';

    let apply = pickFirst(job, [
        'Detail_URL', 'DetailUrl', 'applyLink', 'Apply_Link', 'apply_link',
        'apply', 'Apply', 'ApplyLink', 'applyURL', 'applyUrl', 'jobLink'
    ]) || job.Detail_URL || job.apply_link || job.applyLink || job.apply || job.Apply_Link || '';

    if (!apply || apply.trim().length === 0) {
        const qTitle = encodeURIComponent(title || '');
        const qCompany = encodeURIComponent(company || '');
        apply = `https://www.google.com/search?q=${[qTitle, qCompany, 'internship apply'].filter(Boolean).join('+')}`;
    }

    return {
        Website: siteName,
        Title: title || pickAnyString(job),
        Company: company,
        Location: location,
        StipendOrDuration: stipend || duration,
        Apply_URL: (s(apply) || '#')
    };
}



// ---------- Table & Filters ----------
function applyFilters() {
    const query = searchBar.value.trim().toLowerCase();
    const paidOnly = paidOnlyCheckbox.checked;

    const rows = tbody.querySelectorAll("tr");
    rows.forEach(row => {
        const title = row.cells[0].textContent.toLowerCase();
        const company = row.cells[1].textContent.toLowerCase();
        const stipend = row.cells[3].textContent.trim().toLowerCase();
        let show = true;

        // Search filter
        if (query && !title.includes(query) && !company.includes(query)) show = false;

        // Paid filter
        if (paidOnly && (stipend === "unpaid")) show = false;

        row.style.display = show ? "" : "none";
    });
}


searchBar.addEventListener("input", applyFilters);
paidOnlyCheckbox.addEventListener("change", applyFilters);

function renderTable() {
    tbody.innerHTML = "";
    const sites = Object.keys(cachedResults);
    if (!sites.length) {
        table.style.display = "none";
        return;
    }

    for (const site of sites) {
        const jobs = Array.isArray(cachedResults[site]) ? cachedResults[site] : [];
        jobs.forEach(job => {
            console.log("Site Name:", site, "Job Raw Data:", job); // <<< ADD THIS LINE
            const norm = normalizeJob(site, job);
            const tr = document.createElement("tr");

            const websiteTd = document.createElement("td");
            websiteTd.textContent = norm.Website || site;

            const titleTd = document.createElement("td");
            titleTd.textContent = norm.Title || '';

            const companyTd = document.createElement("td");
            companyTd.textContent = norm.Company || '';

            const locationTd = document.createElement("td");
            locationTd.textContent = norm.Location || '';

            const sdTd = document.createElement("td");
            sdTd.textContent = norm.StipendOrDuration || '';


            // --- Bookmark TD ---
            const bookmarkTd = document.createElement("td");
            const bookmarkIcon = document.createElement("span");

            // Unique ID based on site + title
            const jobId = site + "_" + norm.Title + "_" + norm.Company;

            // Display filled/star icon depending on saved state
            bookmarkIcon.textContent = bookmarks[jobId] ? "★" : "☆";
            bookmarkIcon.classList.add("bookmark-icon");
            if (bookmarks[jobId]) bookmarkIcon.classList.add("active");

            // Toggle bookmark on click
            bookmarkIcon.addEventListener("click", () => {
                if (bookmarks[jobId]) {
                    delete bookmarks[jobId];
                    bookmarkIcon.textContent = "☆";
                    bookmarkIcon.classList.remove("active");
                } else {
                    bookmarks[jobId] = norm;
                    bookmarkIcon.textContent = "★";
                    bookmarkIcon.classList.add("active");
                }
                chrome.storage.local.set({ bookmarks });
            });

            bookmarkTd.appendChild(bookmarkIcon);



            const linkTd = document.createElement("td");
            const a = document.createElement("a");
            a.href = norm.Apply_URL || '#';
            a.target = "_blank";
            a.rel = "noopener noreferrer";
            a.textContent = "Apply";
            linkTd.appendChild(a);

            //tr.appendChild(websiteTd);
            tr.appendChild(titleTd);
            tr.appendChild(companyTd);
            tr.appendChild(locationTd);
            tr.appendChild(sdTd);
            tr.appendChild(linkTd);
            tr.appendChild(bookmarkTd);
            tbody.appendChild(tr);
        });
    }

    table.style.display = "table";
    status.style.display = "none";
    applyFilters();
}


// ---------- Scraper Logic ----------
function saveCache() {
    chrome.storage.local.set({ cachedResults }, () => {
        console.log("Cache saved. Keys:", Object.keys(cachedResults));
    });
}

function loadCache() {
    status.style.display = "block";
    status.textContent = "Loading cached results...";

    chrome.storage.local.get(['cachedResults'], (result) => {
        cachedResults = result.cachedResults || {};
        if (Object.keys(cachedResults).length > 0) renderTable();
        else {
            showLoading();
            scrapeAllSites();
        }
    });

    chrome.storage.local.get(['bookmarks'], (result) => {
        bookmarks = result.bookmarks || {};
    });

}

async function scrapeAllSites() {
    status.style.display = "block";
    status.textContent = "Scraping all websites, this may take a while...";
    const finalResults = {};

    for (const scraper of scrapers) {
        status.textContent = `Scraping ${scraper.name}...`;
        try {
            const data = await scraper.fn();
            finalResults[scraper.name] = Array.isArray(data) ? data : [];
        } catch (err) {
            console.error(`Error scraping ${scraper.name}:`, err);
            finalResults[scraper.name] = [];
        }
    }

    cachedResults = finalResults;
    saveCache();
    hideLoading();
    renderTable();
}

refreshBtn.addEventListener("click", () => {
    showLoading();
    status.style.display = "block";
    status.textContent = "Refreshing all scrapers...";
    cachedResults = {};
    chrome.storage.local.remove('cachedResults', () => {
        scrapeAllSites();
    });
});

homeBtn.addEventListener("click", () => {
    renderTable();
});


document.getElementById("bookmark-tab-btn").addEventListener("click", () => {
    tbody.innerHTML = "";
    table.style.display = "table";
    status.style.display = "none";

    Object.values(bookmarks).forEach(norm => {
        const tr = document.createElement("tr");

        const titleTd = document.createElement("td");
        titleTd.textContent = norm.Title;

        const companyTd = document.createElement("td");
        companyTd.textContent = norm.Company;

        const locationTd = document.createElement("td");
        locationTd.textContent = norm.Location;

        const sdTd = document.createElement("td");
        sdTd.textContent = norm.StipendOrDuration;

        const linkTd = document.createElement("td");
        const a = document.createElement("a");
        a.href = norm.Apply_URL;
        a.target = "_blank";
        a.textContent = "Apply";
        linkTd.appendChild(a);

        // Remove bookmark button inside bookmark tab
        const removeTd = document.createElement("td");
        const removeIcon = document.createElement("span");
        removeIcon.textContent = "✖";
        removeIcon.style.cursor = "pointer";
        removeIcon.style.color = "red";
        removeIcon.addEventListener("click", () => {
            // Remove from storage
            const jobId = norm.Website + "_" + norm.Title + "_" + norm.Company;
            delete bookmarks[jobId];
            chrome.storage.local.set({ bookmarks });

            // Refresh list
            removeTd.parentElement.remove();
        });
        removeTd.appendChild(removeIcon);

        tr.appendChild(titleTd);
        tr.appendChild(companyTd);
        tr.appendChild(locationTd);
        tr.appendChild(sdTd);
        tr.appendChild(linkTd);
        tr.appendChild(removeTd);

        tbody.appendChild(tr);
    });
});

// Initial load
loadCache();
