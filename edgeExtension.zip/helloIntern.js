const table = document.getElementById("internship-table");
const tbody = document.getElementById("table-body");
const status = document.getElementById("status");

const HELLOINTERN_URL = "https://hellointern.in/internships?keyword=&search_post_type=internships&search_user=&search_category=business-finance,data-analysis-science,engineering-technology,technology-software-development&search_cities=&search_states=&search_job_type=&search_employment_type=&search_qualification=&search_page=2&search_company=&search_listing_type=";

// export async function scrapeHelloIntern() {
//   status.textContent = "Opening HelloIntern page and scraping...";

//   try {
//     const tab = await chrome.tabs.create({ url: HELLOINTERN_URL, active: false });

//     setTimeout(() => {
//       chrome.scripting.executeScript(
//         {
//           target: { tabId: tab.id },
//           func: scrapeHelloInternJobs
//         },
//         (results) => {
//           if (results && results[0] && results[0].result) {
//             const internships = results[0].result;

//             tbody.innerHTML = "";
//             internships.forEach(job => {
//               const tr = document.createElement("tr");
//               tr.innerHTML = `
//                 <td>${job.Title}</td>
//                 <td>${job.Company}</td>
//                 <td>${job.Location}</td>
//                 <td>${job.Stipend}</td>
//                 <td>${job.Internship_Type}</td>
//                 <td>${job.Internship_Mode}</td>
//                 <td>${job.Hiring_Status}</td>
//                 <td>${job.Posted_Ago}</td>
//                 <td><a href="${job.Detail_URL}" target="_blank">Apply</a></td>
//               `;
//               tbody.appendChild(tr);
//             });

//             status.style.display = "none";
//             table.style.display = "table";

//             // Close temporary tab
//             chrome.tabs.remove(tab.id);
//           }
//         }
//       );
//     }, 8000); // Wait 8 seconds for dynamic content to load
//   } catch (err) {
//     status.textContent = "Error: " + err.message;
//   }
// }
export async function scrapeHelloIntern() {
  try {
    const tab = await chrome.tabs.create({ url: HELLOINTERN_URL, active: false });

    return await new Promise((resolve, reject) => {
      setTimeout(() => {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            func: scrapeHelloInternJobs
          },
          (results) => {
            chrome.tabs.remove(tab.id);

            if (!results || !results[0]) return resolve([]);

            resolve(results[0].result || []);
          }
        );
      }, 8000);
    });

  } catch (err) {
    console.error(err);
    return [];
  }
}

// Function to run inside HelloIntern page
function scrapeHelloInternJobs() {
  const cards = document.querySelectorAll("div.dz-card.card.style-2.clickable-card");
  const internships = [];

  cards.forEach(card => {
    const getText = (selector) => card.querySelector(selector)?.innerText.trim() || '';
    const getHref = (selector) => card.querySelector(selector)?.href || '';

    const tags = card.querySelectorAll(".btn-group a.btn");
    const tagTexts = Array.from(tags).map(t => t.innerText.trim());

    const footerSpans = card.querySelectorAll(".card-footer span.location");

    let Title = getText("h5.title a");
    let Company = getText("span.c-name");

    let Apply_Link = getHref("h5.title a");

    // 🌟 GOOGLE FALLBACK
    if (!Apply_Link || Apply_Link.trim() === "") {
      Apply_Link =
        "https://www.google.com/search?q=" +
        encodeURIComponent(`${Title} ${Company} internship apply`);
    }

    internships.push({
      Title,
      Detail_URL: Apply_Link, // keeping same structure = detail link
      Company,
      Company_Logo_URL: card.querySelector("div.c-logo img")?.src || '',
      Internship_Type: tagTexts[0] || '',
      Internship_Mode: tagTexts[1] || '',
      Hiring_Status: tagTexts[2] || '',
      Location: footerSpans[0]?.innerText.replace("📍", "").trim() || '',
      Stipend: footerSpans[1]?.innerText.replace("💳", "").trim() || '',
      Posted_Ago: getText("div.right-content span.time")
    });
  });

  return internships;
}


